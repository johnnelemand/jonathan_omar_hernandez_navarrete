//
//  ViewController.swift
//  ScanApp
//
//  Created by Johnne Lemand on 28/05/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    

}
