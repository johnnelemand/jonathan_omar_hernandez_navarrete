//
//  DatosViewController.swift
//  ScanApp
//
//  Created by Johnne Lemand on 28/05/23.
//

import UIKit

class DatosViewController: UIViewController {

    @IBOutlet weak var qrLabel: UILabel!
    
     var recivedString = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("dataqr")
       print(recivedString)
        
        DispatchQueue.main.async { [weak self] in
                    self?.qrLabel.text = self?.recivedString
                }
        
        if let url = URL(string: recivedString), UIApplication.shared.canOpenURL(url) {
                    UIApplication.shared.open(url)
                }
        
    }
    
    

    

}
