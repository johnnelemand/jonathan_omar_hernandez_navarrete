import Foundation

func areSimilar(_ a: [Int], _ b: [Int]) -> Bool {
    // Verificar si los arreglos ya son iguales con sentencias
    if a == b {
        print("Los arreglos son iguales.")
        return true
    }
    
    // Encontrar los indices donde los elementos se difieren
    var diffIndices = [Int]()
    for i in 0..<a.count {
        if a[i] != b[i] {
            diffIndices.append(i)
        }
    }
    
    // Verificamos si los arreglos pueden ser similares al intercambiar a la suma un par de elementos
    if diffIndices.count == 2 {
        let index1 = diffIndices[0]
        let index2 = diffIndices[1]
        if a[index1] == b[index2] && a[index2] == b[index1] {
            print("Se pueden intercambiar elementos para hacer los arreglos sean similares")
            return true
        }
    }
    
    print("Los arreglos no son similares")
    return false
}

// ejemplos para iterar que son similares 
let arregloA = [1, 2, 3]
let arregloB = [2, 1, 3]
let resultado = areSimilar(arregloA, arregloB)
print("¿Son similares? \(resultado)")
