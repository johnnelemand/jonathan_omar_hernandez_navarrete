//
//  EditViewController.swift
//  vistalogin
//
//  Created by Johnne Lemand on 28/05/23.
//

import UIKit

class EditViewController: UIViewController {
    
    var name: String?
    var email: String?
    var phone: String?
    var pass: String?
    var insta: String?
    var birthday: String?
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var passLabel: UILabel!
    @IBOutlet weak var mailLabel: UILabel!
    @IBOutlet weak var instaLabel: UILabel!
    @IBOutlet weak var phoneLabel: UILabel!
    @IBOutlet weak var birthdayLabel: UILabel!
    
    @IBOutlet weak var userLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        nameLabel.text = name
        mailLabel.text = email
        phoneLabel.text = phone
        passLabel.text = pass
        instaLabel.text = insta
        birthdayLabel.text = birthday
        userLabel.text = name
        
        
        
        
        
    }
    
    
    
}







