//
//  ViewController.swift
//  vistalogin
//
//  Created by Johnne Lemand on 27/05/23.
//

import UIKit
import CoreData


class ViewController: UIViewController {

    @IBOutlet weak var passTextfield: UITextField!
    @IBOutlet weak var mailTextfield: UITextField!
    @IBOutlet weak var instaTextfield: UITextField!
    @IBOutlet weak var phoneTexfield: UITextField!
    @IBOutlet weak var birthdayTexfield: UITextField!
    @IBOutlet weak var nameTexField: UITextField!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
         
        mailTextfield.leftSideImge(ImageViewName: "email")
        passTextfield.leftSideImge(ImageViewName: "eye")
        instaTextfield.leftSideImge(ImageViewName: "insta")
        phoneTexfield.leftSideImge(ImageViewName: "phone")
        birthdayTexfield.leftSideImge(ImageViewName: "calendar")
        nameTexField.leftSideImge(ImageViewName: "user")
        
        
        
    }

    

    @IBAction func saveButton(_ sender: Any) {
        /*guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
                return
            }
            
            let context = appDelegate.dataController.viewContext
            
            guard let entity = NSEntityDescription.entity(forEntityName: "User", in: context) else {
                return
            }
            
            let newUser = NSManagedObject(entity: entity, insertInto: context)
            
            newUser.setValue(nameTexField.text, forKey: "name")
            newUser.setValue(mailTextfield.text, forKey: "mail")
            newUser.setValue(phoneTexfield.text, forKey: "phone")
            newUser.setValue(passTextfield.text, forKey: "pass")
            newUser.setValue(instaTextfield.text, forKey: "insta")
            newUser.setValue(birthdayTexfield.text, forKey: "birthday")
            
            appDelegate.dataController.saveContext()
            
            let viewC = storyboard?.instantiateViewController(withIdentifier: "EditViewController") as! EditViewController
            viewC.name = nameTexField.text
            viewC.pass = passTextfield.text
            viewC.birthday = birthdayTexfield.text
            viewC.insta = instaTextfield.text
            viewC.phone = phoneTexfield.text
            viewC.email = mailTextfield.text
            navigationController?.pushViewController(viewC, animated: true)
        }*/
        let viewC = self.storyboard?.instantiateViewController(withIdentifier: "EditViewController") as! EditViewController
        viewC.name = nameTexField.text!
        viewC.pass = passTextfield.text!
        viewC.birthday = birthdayTexfield.text!
        viewC.insta = instaTextfield.text!
        viewC.phone = phoneTexfield.text!
        viewC.email = mailTextfield.text!
        self.navigationController?.pushViewController(viewC, animated: true)
    
    }
    
            
            
}

//implemantar coredata
/*class DataController {
    static let shared = DataController()
    
    lazy var persistentContainer: NSPersistentContainer = {
        
        let container = NSPersistentContainer(name: "ModelUser")
        
        container.loadPersistentStores { (_, error) in
            if let error = error {
                fatalError("No se pudo cargar el almacén persistente de Core Data: \(error)")
            }
        }
        return container
    }()
    
    var viewContext: NSManagedObjectContext {
        return persistentContainer.viewContext
    }
    
    func saveContext() {
        if viewContext.hasChanges {
            do {
                try viewContext.save()
            } catch {
                let nsError = error as NSError
                fatalError("Error al guardar en el contexto de Core Data: \(nsError)")
            }
        }
    }
}*/



extension UITextField{
    
    func leftSideImge(ImageViewName: String){
        let imageView = UIImageView(frame: CGRect(x: 10, y: 10, width: 20, height: 20))
        imageView.image = UIImage(named: ImageViewName)
        let imageViewContainerView = UIView(frame: CGRect(x: 0, y: 0, width: 55, height: 40))
        imageViewContainerView.addSubview(imageView)
        leftView = imageViewContainerView
        leftViewMode = .always
        self.tintColor = .lightGray
    }
    
    
    
}


