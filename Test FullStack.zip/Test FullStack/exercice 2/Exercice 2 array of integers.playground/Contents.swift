func differentSymbolsNaive(_ s: String) -> Int {
    var uniqueChars = Set<Character>()
    
    // Add each unique character to the set
    s.forEach { uniqueChars.insert($0) }
    
    let count = uniqueChars.count
    print("The string '\(s)' has \(count) different characters")
    return count
}

// Example to know how many different characters there are:
//let string = "cabcar"
let string = "cabca"
let result = differentSymbolsNaive(string)
print("Number of different characters: \(result)")


